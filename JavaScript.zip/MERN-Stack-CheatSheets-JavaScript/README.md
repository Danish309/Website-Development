# Web-Technologies

This repositry is of practice projects/codes for my Course in University.


                          --------------------------------MERN STACK DEVELOPMENT--------------------------------



1. Webpage - HTML,CSS.

2. Server
               ii. Node.Js
  a. Create Server to run on a Port
  b. Create your own Module
  
  
               iii. Express.Js
   a. Route Methods
   b. Route Handlers
   
4. Database
 
                iv. MongoDB
   a. Create Database
   b. Add Collection
   c. Add Entry
   d. Update Entry
   e. Delete Entry
   
5. Front - End
                v. EJS Framework - Embedded JavaScript
               vi. BootStrap
               vii. ReactJs
