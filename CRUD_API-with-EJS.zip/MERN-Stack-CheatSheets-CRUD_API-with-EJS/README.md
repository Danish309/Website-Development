# Web-Technologies

This repositry is of practice projects/codes for my Course in University.


                          --------------------------------MERN STACK DEVELOPMENT--------------------------------



1. Webpage - HTML,CSS.

2. Node.Js
 
  a. Create Server to run on a Port
  b. Create your own Module
  
3. Express.Js

   a. Route Methods
   b. Route Handlers
   
4. MongoDB
