# Web-Technologies

This repositry is of practice projects/codes for my Course in University.

------------------------------------------------------------------------MERN STACK DEVELOPMENT----------------------------------------------------------------------------------


1. Webpage - HTML,CSS.

2. Node.Js
 
  a. Create Server to run on a Port
  b. Create your own Module
