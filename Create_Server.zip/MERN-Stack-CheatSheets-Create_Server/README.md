# Web-Technologies

This repositry is of practice projects/codes for my Course in University.

1. Webpage - HTML,CSS.
2. Node 
  a. Create Server to run on a Port
  b. Create your own Module
  
