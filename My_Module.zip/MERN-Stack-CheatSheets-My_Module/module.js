exports.GiveDate=()=>
{
    return Date()
}

exports.Information=()=>
{
    return "Danish Kumar\nSemester 6\nSection D\nBS-CS"
}